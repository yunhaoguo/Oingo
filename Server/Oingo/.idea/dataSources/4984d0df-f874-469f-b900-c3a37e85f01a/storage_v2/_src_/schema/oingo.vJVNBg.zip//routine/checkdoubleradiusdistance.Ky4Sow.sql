create function checkDoubleRadiusDistance(loc1 point, loc2 point, radius1 int, radius2 int)
  returns tinyint(1)
  begin
	declare result boolean;
	declare distance double;
	set distance=ST_Distance_Sphere(loc1, loc2);
	if (distance<radius1 or radius1 is null) and (distance<radius2 or radius2 is null) then
		set result=true;
	else
		set result=false;
	end if;
	return result;
end;

