create function checkTimeOverlapping(fstarttime  datetime, fendtime datetime, nstarttime datetime, nendtime datetime,
                                     repeat_type varchar(50))
  returns tinyint(1)
  begin
	declare result boolean;
	if repeat_type is null then
		-- if the note is non-repeatitive, then we compare the time section directly
		if nstarttime>fendtime or fstarttime>nendtime then
			set result=false;
		else
			set result=true;
		end if;
	else
		-- if the note is repeatitive
        -- which indicating that the nstarttime and nendtime is in one day.
        if date(fstarttime)=date(fendtime) then
			-- if the filter time is in one day
            if dayofweek(fstarttime)=dayofweek(nstarttime) then
				if nstarttime>fendtime or fstarttime>nendtime then
					set result=false;
				else
					set result=true;
				end if;
            else
				set result=false;
            end if;
		else
			-- if the filter time spread on days
			if (date(fendtime)-date(fstarttime))>=7 then
				set result=true;
			else
				if dayofweek(fstarttime)<dayofweek(fendtime) and dayofweek(nstarttime)>=dayofweek(fstarttime) and dayofweek(nendtime)<=dayofweek(fstarttime) then
                    if time(nstarttime)>time(fendtime) or time(fstarttime)>time(nendtime) then
						set result=false;
					else
						set result=true;
					end if;
				elseif dayofweek(fstarttime)>dayofweek(fendtime) and (dayofweek(nstarttime)<=dayofweek(fstarttime) or dayofweek(nstarttime)>=dayofweek(fendtime)) then
					if time(nstarttime)>time(fendtime) or time(fstarttime)>time(nendtime) then
						set result=false;
					else
						set result=true;
					end if;
				else
					set result=false;
				end if;
            end if;
        end if;
    end if;
    return result;
end;

